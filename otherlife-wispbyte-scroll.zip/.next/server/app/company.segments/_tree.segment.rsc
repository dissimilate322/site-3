:HL["/_next/static/chunks/3s023ph69p-m1.css","style"]
:HL["/_next/static/chunks/19wwhvvfdxefa.css","style"]
:HL["/assets/ff9ccf87d4ee1f04-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
:HL["/assets/f6b0aeaf3ea04f3b-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"company","h":96,"c":"$Q2"}]]
0:{"b":"NNKZNU3xSY0IvPrs6suLC","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
