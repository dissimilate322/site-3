1:"$Sreact.fragment"
2:"/_next/static/chunks/0ckxx8n686uo5.js"
3:"/_next/static/chunks/1oko4h00z6rmy.js"
4:"/_next/static/chunks/0icqp5p40c_j3.js"
5:I[30966,["$2","$3","$4"],"default"]
6:I[20032,["$2","$3","$4"],"default"]
7:I[56253,["$2","$3","$4"],"default"]
8:I[39756,["$2","$3","$4"],"default"]
9:I[37457,["$2","$3","$4"],"default"]
d:"/_next/static/chunks/0chi2uyhmsdtv.js"
e:I[66492,["$2","$3","$4","$d"],"default"]
f:I[97367,["$2","$3","$4"],"OutletBoundary"]
10:"$Sreact.suspense"
12:"ViewportBoundary"
13:I[97367,["$2","$3","$4"],"$12"]
15:"MetadataBoundary"
16:I[97367,["$2","$3","$4"],"$15"]
18:I[68027,["$2","$3","$4"],"default",1]
:HL["/_next/static/chunks/2pro2_h4snbrg.css","style"]
:HL["/_next/static/chunks/17eq0vy_cyam4.css","style"]
:HL["/assets/ff9ccf87d4ee1f04-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
:HL["/assets/f6b0aeaf3ea04f3b-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
b:X
c:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$Le",null,{}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/17eq0vy_cyam4.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0chi2uyhmsdtv.js","async":true,"nonce":"$undefined"}]],["$","$Lf",null,{"children":["$","$10",null,{"name":"Next.MetadataOutlet","children":"$@11"}]}]]}],"p":false,"v":null}}]]
a:[["children",{"s":"work","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$b"},"c":"$Qc"}]]
0:{"P":null,"c":["","work"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2pro2_h4snbrg.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0ckxx8n686uo5.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/1oko4h00z6rmy.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/0icqp5p40c_j3.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","data-motion":"full","data-site-version":"reference-webgl-20261025","children":[["$","head",null,{"children":[["$","link",null,{"rel":"preload","href":"/assets/ff9ccf87d4ee1f04-s.p.ttf","as":"font","type":"font/ttf","crossOrigin":"anonymous"}],["$","link",null,{"rel":"preload","href":"/assets/f6b0aeaf3ea04f3b-s.p.ttf","as":"font","type":"font/ttf","crossOrigin":"anonymous"}]]}],["$","body",null,{"children":["$","$L5",null,{"children":[["$","$L6",null,{}],["$","$L7",null,{"children":["$","$L8",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L9",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]}]]}]]}],"p":false,"v":null},"c":"$Qa"},"h":{"r":["$","$1","h",{"children":[null,["$","$L13",null,{"children":"$L14"}],["$","$L16",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$10",null,{"name":"Next.Metadata","children":"$L17"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$18",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2pro2_h4snbrg.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"tA4LHTPPRFmjfHWRVJvo4"}
b:C
14:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
19:I[27201,["$2","$3","$4"],"IconMark"]
11:null
17:[["$","title","0",{"children":"Our Work | Unconventional Solutions"}],["$","meta","1",{"name":"description","content":"Otherlife is a creative agency elevating digital experiences using creativity and technology."}],["$","link","2",{"rel":"icon","href":"/assets/favicon-32x32.png"}],["$","$L19","3",{}]]
