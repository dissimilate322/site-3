globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/xnfJEu4kpqAs7xNvNnRVN/_buildManifest.js",
    "static/xnfJEu4kpqAs7xNvNnRVN/_ssgManifest.js",
    "static/xnfJEu4kpqAs7xNvNnRVN/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/31qp8jfkw0x2h.js",
    "static/chunks/1tty6l8tgntgq.js",
    "static/chunks/216iyidhmrh3u.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/31qp8jfkw0x2h.js",
        "static/chunks/1tty6l8tgntgq.js",
        "static/chunks/216iyidhmrh3u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/31qp8jfkw0x2h.js",
        "static/chunks/1tty6l8tgntgq.js",
        "static/chunks/216iyidhmrh3u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/31qp8jfkw0x2h.js",
        "static/chunks/1tty6l8tgntgq.js",
        "static/chunks/216iyidhmrh3u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/work/page": {
      "otherChunks": [
        "static/chunks/31qp8jfkw0x2h.js",
        "static/chunks/1tty6l8tgntgq.js",
        "static/chunks/216iyidhmrh3u.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
