'use strict';
process.env.HOSTNAME = '0.0.0.0';
process.env.PORT = process.env.PORT || process.env.SERVER_PORT || '3000';
require('./server.js');
