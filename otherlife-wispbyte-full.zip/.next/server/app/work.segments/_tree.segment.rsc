:HL["/_next/static/chunks/3x18d4by6webw.css","style"]
:HL["/_next/static/chunks/23rf5cp4dxrks.css","style"]
:HL["/assets/ff9ccf87d4ee1f04-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
:HL["/assets/f6b0aeaf3ea04f3b-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"work","h":96,"c":"$Q2"}]]
0:{"b":"Y7dH_tnqa2MmTSNbAwdoU","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
