module.exports=[95466,a=>{"use strict";var b=a.i(87924);a.s(["default",0,function({children:a="Contact Us",subject:c="",className:d=""}){return(0,b.jsx)("button",{type:"button",className:d,onClick:()=>window.dispatchEvent(new CustomEvent("site:contact",{detail:c})),children:a})}])}];

//# sourceMappingURL=src_components_ContactButton_tsx_1lu2yufdn9g1r._.js.map