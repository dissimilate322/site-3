1:"$Sreact.fragment"
2:"/_next/static/chunks/3ewjv2wje8-9h.js"
3:"/_next/static/chunks/1m1tp6phisvm4.js"
4:I[30966,["$2","$3"],"default"]
5:I[56253,["$2","$3"],"default"]
6:I[39756,["$2","$3"],"default"]
7:I[37457,["$2","$3"],"default"]
b:"/_next/static/chunks/0chi2uyhmsdtv.js"
c:I[66492,["$2","$3","$b"],"default"]
d:I[97367,["$2","$3"],"OutletBoundary"]
e:"$Sreact.suspense"
10:"ViewportBoundary"
11:I[97367,["$2","$3"],"$10"]
13:"MetadataBoundary"
14:I[97367,["$2","$3"],"$13"]
16:I[68027,["$2","$3"],"default",1]
:HL["/_next/static/chunks/3s023ph69p-m1.css","style"]
:HL["/_next/static/chunks/3feskmd4nvfs_.css","style"]
:HL["/assets/ff9ccf87d4ee1f04-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
:HL["/assets/f6b0aeaf3ea04f3b-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
9:X
a:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$Lc",null,{}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3feskmd4nvfs_.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0chi2uyhmsdtv.js","async":true,"nonce":"$undefined"}]],["$","$Ld",null,{"children":["$","$e",null,{"name":"Next.MetadataOutlet","children":"$@f"}]}]]}],"p":false,"v":null}}]]
8:[["children",{"s":"work","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$9"},"c":"$Qa"}]]
0:{"P":null,"c":["","work"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3s023ph69p-m1.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/3ewjv2wje8-9h.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/1m1tp6phisvm4.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","data-motion":"full","data-site-version":"motion-settings-20261025","children":[["$","head",null,{"children":[["$","link",null,{"rel":"preload","href":"/assets/ff9ccf87d4ee1f04-s.p.ttf","as":"font","type":"font/ttf","crossOrigin":"anonymous"}],["$","link",null,{"rel":"preload","href":"/assets/f6b0aeaf3ea04f3b-s.p.ttf","as":"font","type":"font/ttf","crossOrigin":"anonymous"}]]}],["$","body",null,{"children":["$","$L4",null,{"children":["$","$L5",null,{"children":["$","$L6",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L7",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}]]}],"p":false,"v":null},"c":"$Q8"},"h":{"r":["$","$1","h",{"children":[null,["$","$L11",null,{"children":"$L12"}],["$","$L14",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$e",null,{"name":"Next.Metadata","children":"$L15"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$16",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3s023ph69p-m1.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"xHEi3Bk8-UxfEkz3Y1QLq"}
9:C
12:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
17:I[27201,["$2","$3"],"IconMark"]
f:null
15:[["$","title","0",{"children":"Our Work | Unconventional Solutions"}],["$","meta","1",{"name":"description","content":"Otherlife is a creative agency elevating digital experiences using creativity and technology."}],["$","link","2",{"rel":"icon","href":"/assets/favicon-32x32.png"}],["$","$L17","3",{}]]
