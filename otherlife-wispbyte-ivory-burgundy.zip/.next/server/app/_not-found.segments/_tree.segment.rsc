:HL["/_next/static/chunks/1039k39eznmed.css","style"]
:HL["/assets/ff9ccf87d4ee1f04-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
:HL["/assets/f6b0aeaf3ea04f3b-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"/_not-found","h":96,"c":"$Q2"}]]
0:{"b":"nQ4IqCyuma2v7Z3t7sx57","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
