:HL["/_next/static/chunks/3x18d4by6webw.css","style"]
:HL["/_next/static/chunks/0w5ez0288rolv.css","style"]
:HL["/assets/ff9ccf87d4ee1f04-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
:HL["/assets/f6b0aeaf3ea04f3b-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":{"n":"slug","t":"d","k":"narcos","s":[]},"h":65632,"c":"$Q3"}]]
1:[["children",{"s":"work","h":131168,"c":"$Q2"}]]
0:{"b":"9VdOf9Zk4IMGkSZ3EUcNE","t":{"t":{"s":"","h":131152,"c":"$Q1"}}}
