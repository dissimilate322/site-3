:HL["/_next/static/chunks/3933cfomm0fy4.css","style"]
:HL["/_next/static/chunks/3wikvl57iy7ef.css","style"]
:HL["/assets/ff9ccf87d4ee1f04-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
:HL["/assets/f6b0aeaf3ea04f3b-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":{"n":"slug","t":"d","k":"senior-designer","s":[]},"h":65632,"c":"$Q3"}]]
1:[["children",{"s":"careers","h":131168,"c":"$Q2"}]]
0:{"b":"c0ePa1kfyJsJQl8MDAcCu","t":{"t":{"s":"","h":131152,"c":"$Q1"}}}
