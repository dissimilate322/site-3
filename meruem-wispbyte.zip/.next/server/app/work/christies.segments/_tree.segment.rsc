:HL["/_next/static/chunks/33ti83ww9yztp.css","style"]
:HL["/_next/static/chunks/01vs5aqo-1p1q.css","style"]
:HL["/assets/ff9ccf87d4ee1f04-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
:HL["/assets/f6b0aeaf3ea04f3b-s.p.ttf","font",{"crossOrigin":"anonymous","type":"font/ttf"}]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":{"n":"slug","t":"d","k":"christies","s":[]},"h":65632,"c":"$Q3"}]]
1:[["children",{"s":"work","h":131168,"c":"$Q2"}]]
0:{"b":"nqr-QkW35orJPAUaOMb-C","t":{"t":{"s":"","h":131152,"c":"$Q1"}}}
