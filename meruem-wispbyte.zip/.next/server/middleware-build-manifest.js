globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/W9lUVogW3-KFHgicwXqeE/_buildManifest.js",
    "static/W9lUVogW3-KFHgicwXqeE/_ssgManifest.js",
    "static/W9lUVogW3-KFHgicwXqeE/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0om590q-tq0l9.js",
    "static/chunks/0s2cptn1mmf6r.js",
    "static/chunks/216iyidhmrh3u.js",
    "static/chunks/0v2azvilwavbo.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/0v2azvilwavbo.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/0v2azvilwavbo.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/0v2azvilwavbo.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/careers/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/0v2azvilwavbo.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/careers/[slug]/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/0v2azvilwavbo.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/company/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/0v2azvilwavbo.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/work/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/0v2azvilwavbo.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/work/[slug]/page": {
      "otherChunks": [
        "static/chunks/0om590q-tq0l9.js",
        "static/chunks/0s2cptn1mmf6r.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/0v2azvilwavbo.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
